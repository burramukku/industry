package com.mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/f1")
public class f1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pa = request.getParameter("email");
        String ps = request.getParameter("pass");
        String email = "";
        String password = "";
        String name = "";
        String gender = "";
        String mobile = "";
        String percentage = "";
        String eduQf = "";
        String course = "";

        ArrayList<String> a = new ArrayList<>();
        ArrayList<String> b = new ArrayList<>();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Updated driver class name
            try (
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
                PreparedStatement p = con.prepareStatement("SELECT Email, password FROM used");
            ) {
                ResultSet rSet = p.executeQuery();

                while (rSet.next()) {
                    String Email = rSet.getString("Email");
                    String pass = rSet.getString("password");
                    a.add(Email);
                    b.add(pass);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        int ans = 0;

        for (int i = 0; i < a.size(); i++) {
            if (pa.equals(a.get(i)) && ps.equals(b.get(i))) {
                ans = 1;
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver"); // Updated driver class name
                    try (
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
                        PreparedStatement p = con.prepareStatement("SELECT Email, password, name, Gender, Mobile, percentage, eduQf, Course FROM used WHERE Email=? AND password=?");
                    ) {
                        p.setString(1, pa);
                        p.setString(2, ps);
                        ResultSet resultSet = p.executeQuery();
                        while (resultSet.next()) {
                            email = resultSet.getString("Email");
                            password = resultSet.getString("password");
                            name = resultSet.getString("name");
                            gender = resultSet.getString("Gender");
                            mobile = resultSet.getString("Mobile");
                            percentage = resultSet.getString("percentage");
                            eduQf = resultSet.getString("eduQf");
                            course = resultSet.getString("Course");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                request.setAttribute("password", password);
                request.setAttribute("email", email);
                request.setAttribute("name", name);
                request.setAttribute("gender", gender);
                request.setAttribute("mobile", mobile);
                request.setAttribute("course", course);
                request.setAttribute("percentage", percentage);
                request.setAttribute("eduqf", eduQf);
                request.getRequestDispatcher("/first.jsp").forward(request, response);
                break;
            }
        }

        PrintWriter o = response.getWriter();
        o.print("<html><body>");
        o.print("<script>");
        if (ans > 0) {
            o.print("alert('You have logged in successfully');");
            o.print("window.location.href = 'index3.html';");
        } else {
            o.print("alert('Invalid User');");
            o.print("window.location.href = 'index.html';");
        }
        o.print("</script>");
        o.print("</body></html>");
    }
}
